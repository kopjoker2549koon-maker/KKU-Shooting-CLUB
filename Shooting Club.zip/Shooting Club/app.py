from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'super_secret_key'

AMMO_PRODUCTS = {
    '.177 ปืนยาวอัดลม': {'stock_key': '.177', 'price_per_unit': 2},
    '.177 ปืนสั้นอัดลม': {'stock_key': '.177', 'price_per_unit': 3},
    '.22 ปืนยาวชาวบ้าน': {'stock_key': '.22 ปืนยาวชาวบ้าน', 'price_per_unit': 5}
}

def get_db():
    conn = sqlite3.connect('shooting_club.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS club_inventory (ammo_type TEXT PRIMARY KEY, quantity INTEGER)''')
    c.execute('''CREATE TABLE IF NOT EXISTS user_ammo (user_id INTEGER, ammo_type TEXT, quantity INTEGER, PRIMARY KEY(user_id, ammo_type))''')
    c.execute('''CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT, ammo_type TEXT, amount INTEGER, timestamp TEXT, note TEXT)''')
    
    # เพิ่มคอลัมน์ note กรณีฐานข้อมูลเดิมยังไม่มี
    try:
        c.execute("ALTER TABLE transactions ADD COLUMN note TEXT")
    except sqlite3.OperationalError:
        pass

    c.execute("INSERT INTO users (username, password, role) VALUES ('KoldP', '1987', 'god') ON CONFLICT(username) DO UPDATE SET password='1987', role='god'")
    c.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES ('operator1', 'op123', 'operator')")
    
    c.execute("INSERT OR IGNORE INTO club_inventory VALUES ('.177', 2000)")
    c.execute("INSERT OR IGNORE INTO club_inventory VALUES ('.22 ปืนยาวชาวบ้าน', 2000)")
    c.execute("DELETE FROM club_inventory WHERE ammo_type IN ('.177 ปืนยาวอัดลม', '.177 ปืนสั้นอัดลม')")
    
    conn.commit()
    conn.close()

# ================= Login =================
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        secret_key = request.form.get('secret_god_mode')
        
        if secret_key == 'activated':
            role = 'god'
            
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=? AND role=?", (username, password, role))
        user = c.fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            
            if role == 'god':
                return redirect(url_for('god_admin'))
            elif role == 'operator':
                return redirect(url_for('operator_dashboard'))
            else:
                return redirect(url_for('member'))
        else:
            flash('ชื่อผู้ใช้, รหัสผ่าน หรือประเภทผู้ใช้งานไม่ถูกต้อง')
            
    return render_template('login.html')

# ================= Register =================
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        conn = get_db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, 'member')", (username, password))
            conn.commit()
            flash('สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username นี้มีผู้ใช้งานแล้ว')
        finally:
            conn.close()
            
    return render_template('register.html')

# ================= Member Dashboard =================
@app.route('/member', methods=['GET', 'POST'])
def member():
    if 'user_id' not in session or session.get('role') != 'member':
        return redirect(url_for('login'))
        
    conn = get_db()
    c = conn.cursor()
    user_id = session['user_id']
    
    if request.method == 'POST':
        action = request.form.get('action')
        product_name = request.form.get('ammo_type')
        amount = int(request.form.get('amount'))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        if product_name in AMMO_PRODUCTS:
            stock_key = AMMO_PRODUCTS[product_name]['stock_key']
            price = AMMO_PRODUCTS[product_name]['price_per_unit'] * amount
            
            if action == 'buy':
                c.execute("SELECT quantity FROM club_inventory WHERE ammo_type=?", (stock_key,))
                inv = c.fetchone()
                if inv and inv['quantity'] >= amount:
                    c.execute("UPDATE club_inventory SET quantity = quantity - ? WHERE ammo_type = ?", (amount, stock_key))
                    c.execute("INSERT INTO user_ammo (user_id, ammo_type, quantity) VALUES (?, ?, ?) ON CONFLICT(user_id, ammo_type) DO UPDATE SET quantity=quantity+?", (user_id, product_name, amount, amount))
                    c.execute("INSERT INTO transactions (user_id, action, ammo_type, amount, timestamp, note) VALUES (?, 'Buy', ?, ?, ?, ?)", (user_id, f"{product_name} ({price} บาท)", amount, now, 'สั่งซื้อผ่านระบบ'))
                    flash(f'ซื้อสำเร็จ! ยอดรวม {price} บาท')
                else:
                    flash(f'กระสุนในคลังสนาม ({stock_key}) มีไม่เพียงพอ')
            elif action == 'withdraw':
                c.execute("SELECT quantity FROM user_ammo WHERE user_id=? AND ammo_type=?", (user_id, product_name))
                res = c.fetchone()
                if res and res['quantity'] >= amount:
                    c.execute("UPDATE user_ammo SET quantity = quantity - ? WHERE user_id = ? AND ammo_type = ?", (amount, user_id, product_name))
                    c.execute("INSERT INTO transactions (user_id, action, ammo_type, amount, timestamp, note) VALUES (?, 'Withdraw', ?, ?, ?, ?)", (user_id, product_name, amount, now, 'เบิกซ้อมสนาม'))
                    flash('เบิกกระสุนลงสนามสำเร็จ!')
                else:
                    flash('กระสุนของคุณไม่เพียงพอสำหรับการเบิก')
            conn.commit()

    c.execute("SELECT * FROM user_ammo WHERE user_id=?", (user_id,))
    my_ammo = c.fetchall()
    c.execute("SELECT * FROM transactions WHERE user_id=? ORDER BY timestamp DESC", (user_id,))
    history = c.fetchall()
    conn.close()
    
    return render_template('member.html', my_ammo=my_ammo, history=history, products=AMMO_PRODUCTS)

# ================= Operator Dashboard =================
@app.route('/operator', methods=['GET', 'POST'])
def operator_dashboard():
    if 'user_id' not in session or session.get('role') != 'operator':
        return redirect(url_for('login'))
        
    conn = get_db()
    c = conn.cursor()
    
    if request.method == 'POST':
        action = request.form.get('action')
        ammo_type = request.form.get('ammo_type')
        amount = int(request.form.get('amount'))
        note = request.form.get('note', '').strip()
        if not note:
            note = '-'
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 1. เพิ่มกี่นัด
        if action == 'add_inventory':
            c.execute("UPDATE club_inventory SET quantity = quantity + ? WHERE ammo_type = ?", (amount, ammo_type))
            c.execute("INSERT INTO transactions (user_id, action, ammo_type, amount, timestamp, note) VALUES (?, 'Operator_Add', ?, ?, ?, ?)", (session['user_id'], ammo_type, amount, now, note))
            conn.commit()
            flash(f'เพิ่มสต็อก {ammo_type} จำนวน {amount} นัด สำเร็จ!')

        # 2. ลดกี่นัด
        elif action == 'sub_inventory':
            c.execute("UPDATE club_inventory SET quantity = MAX(0, quantity - ?) WHERE ammo_type = ?", (amount, ammo_type))
            c.execute("INSERT INTO transactions (user_id, action, ammo_type, amount, timestamp, note) VALUES (?, 'Operator_Sub', ?, ?, ?, ?)", (session['user_id'], ammo_type, amount, now, note))
            conn.commit()
            flash(f'ลดสต็อก {ammo_type} จำนวน {amount} นัด เรียบร้อย!')

        # 3. เพิ่ม/ปรับเป็นกี่นัด
        elif action == 'set_inventory':
            c.execute("UPDATE club_inventory SET quantity = ? WHERE ammo_type = ?", (amount, ammo_type))
            c.execute("INSERT INTO transactions (user_id, action, ammo_type, amount, timestamp, note) VALUES (?, 'Operator_Set', ?, ?, ?, ?)", (session['user_id'], ammo_type, amount, now, note))
            conn.commit()
            flash(f'ปรับยอดสต็อก {ammo_type} เป็น {amount} นัด เรียบร้อย!')

    c.execute("SELECT * FROM club_inventory")
    inventory = c.fetchall()
    c.execute("SELECT t.*, u.username FROM transactions t JOIN users u ON t.user_id = u.id ORDER BY t.timestamp DESC")
    all_history = c.fetchall()
    conn.close()
    
    return render_template('operator.html', inventory=inventory, history=all_history)

# ================= God Admin =================
@app.route('/god', methods=['GET', 'POST'])
def god_admin():
    if 'user_id' not in session or session.get('role') != 'god':
        return redirect(url_for('login'))
        
    conn = get_db()
    c = conn.cursor()
    
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add_operator':
            op_user = request.form.get('op_username')
            op_pass = request.form.get('op_password')
            try:
                c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, 'operator')", (op_user, op_pass))
                conn.commit()
                flash(f'สร้าง Operator: {op_user} สำเร็จ!')
            except sqlite3.IntegrityError:
                flash(f'Username {op_user} มีอยู่ในระบบแล้ว')
        elif action == 'edit_operator_pass':
            user_id = request.form.get('user_id')
            new_pass = request.form.get('new_password')
            c.execute("UPDATE users SET password=? WHERE id=? AND role='operator'", (new_pass, user_id))
            conn.commit()
            flash('อัปเดตรหัสผ่าน Operator สำเร็จ!')
        elif action == 'delete_operator':
            user_id = request.form.get('user_id')
            c.execute("DELETE FROM users WHERE id=? AND role='operator'", (user_id,))
            conn.commit()
            flash('ลบ Operator เรียบร้อยแล้ว')

    c.execute("SELECT id, username, password FROM users WHERE role='operator' ORDER BY id ASC")
    operators = c.fetchall()
    conn.close()
    
    return render_template('god.html', operators=operators)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)